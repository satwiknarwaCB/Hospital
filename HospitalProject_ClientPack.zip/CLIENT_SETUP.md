# Client Project Setup Guide

This project consists of a **React Frontend** and a **FastAPI Backend (MongoDB)**. Follow the steps below to set up and run the project locally.

## Prerequisites

Ensure you have the following installed:
- [Node.js](https://nodejs.org/) (v18 or higher)
- [Python 3.9+](https://www.python.org/)
- [MongoDB](https://www.mongodb.com/try/download/community) (Running locally or a MongoDB Atlas URI)

---

## 1. Backend Setup

1. Open a terminal and navigate to the `server` directory:
   ```bash
   cd server
   ```

2. Create a virtual environment (optional but recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Create a `.env` file in the `server` folder (if not already there) and add your MongoDB connection string:
   ```env
   MONGODB_URL=mongodb://localhost:27017
   DATABASE_NAME=therapy_portal
   SECRET_KEY=your-secret-key-change-this
   ```

5. Run the backend server:
   ```bash
   python main.py
   ```
   The backend will be available at `http://localhost:8000`.

---

## 2. Frontend Setup

1. Open a new terminal and navigate to the root directory of the project.

2. Install dependencies:
   ```bash
   npm install
   ```

3. Configure environment variables:
   Ensure there is a `.env` file in the root with the following:
   ```env
   VITE_API_URL=http://localhost:8000
   ```

4. Run the frontend development server:
   ```bash
   npm run dev
   ```
   The frontend will be available at `http://localhost:5173` (or the port specified in the terminal).

---

## Project Structure Overview

- `/src` - React frontend source code (components, pages, hooks).
- `/server` - Python FastAPI backend source code.
- `/public` - Static assets for the frontend.
- `package.json` - Frontend dependencies and scripts.
- `server/requirements.txt` - Backend dependencies.
