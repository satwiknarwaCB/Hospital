"""Routes package"""
from .doctor_auth import router as doctor_auth_router

__all__ = ["doctor_auth_router"]
