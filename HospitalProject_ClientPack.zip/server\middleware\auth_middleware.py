"""
JWT Authentication Middleware
Protects routes by validating JWT tokens
"""
from typing import Optional
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from database import db_manager
from utils.auth import decode_access_token
from models.doctor import DoctorResponse
from models.parent import ParentResponse


# HTTP Bearer token scheme
security = HTTPBearer()


async def get_current_doctor(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> DoctorResponse:
    """
    Dependency to get the current authenticated doctor
    
    Args:
        credentials: HTTP Authorization header with Bearer token
        
    Returns:
        DoctorResponse object
        
    Raises:
        HTTPException: If token is invalid or doctor not found
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    # Extract token
    token = credentials.credentials
    
    # Decode token
    payload = decode_access_token(token)
    if payload is None:
        raise credentials_exception
    
    # Extract doctor ID from token
    doctor_id: str = payload.get("sub")
    if doctor_id is None:
        raise credentials_exception
    
    # Get doctor from database
    doctor_data = db_manager.doctors.find_one({"_id": doctor_id})
    if doctor_data is None:
        raise credentials_exception
    
    # Check if doctor is active
    if not doctor_data.get("is_active", True):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Doctor account is deactivated"
        )
    
    # Return doctor response (without password)
    return DoctorResponse(
        id=doctor_data["_id"],
        name=doctor_data["name"],
        email=doctor_data["email"],
        specialization=doctor_data["specialization"],
        experience_years=doctor_data["experience_years"],
        assigned_patients=doctor_data["assigned_patients"],
        phone=doctor_data.get("phone"),
        license_number=doctor_data.get("license_number"),
        is_active=doctor_data.get("is_active", True),
        role="therapist"
    )


async def get_current_active_doctor(
    current_doctor: DoctorResponse = Depends(get_current_doctor)
) -> DoctorResponse:
    """
    Dependency to get current active doctor (additional layer)
    
    Args:
        current_doctor: Doctor from get_current_doctor dependency
        
    Returns:
        DoctorResponse object
        
    Raises:
        HTTPException: If doctor is not active
    """
    if not current_doctor.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Inactive doctor account"
        )
    return current_doctor


async def get_current_parent(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> ParentResponse:
    """
    Dependency to get the current authenticated parent
    
    Args:
        credentials: HTTP Authorization header with Bearer token
        
    Returns:
        ParentResponse object
        
    Raises:
        HTTPException: If token is invalid or parent not found
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    # Extract token
    token = credentials.credentials
    
    # Decode token
    payload = decode_access_token(token)
    if payload is None:
        raise credentials_exception
    
    # Extract parent ID from token
    parent_id: str = payload.get("sub")
    if parent_id is None:
        raise credentials_exception
    
    # Get parent from database
    parent_data = db_manager.parents.find_one({"_id": parent_id})
    if parent_data is None:
        raise credentials_exception
    
    # Check if parent is active
    if not parent_data.get("is_active", True):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Parent account is deactivated"
        )
    
    # Return parent response (without password)
    return ParentResponse(
        id=parent_data["_id"],
        name=parent_data["name"],
        email=parent_data["email"],
        phone=parent_data.get("phone"),
        children_ids=parent_data.get("children_ids", []),
        childId=parent_data.get("child_id") or (parent_data.get("children_ids")[0] if parent_data.get("children_ids") else None),
        relationship=parent_data.get("relationship"),
        is_active=parent_data.get("is_active", True)
    )


async def get_current_active_parent(
    current_parent: ParentResponse = Depends(get_current_parent)
) -> ParentResponse:
    """
    Dependency to get current active parent (additional layer)
    
    Args:
        current_parent: Parent from get_current_parent dependency
        
    Returns:
        ParentResponse object
        
    Raises:
        HTTPException: If parent is not active
    """
    if not current_parent.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Inactive parent account"
        )
    return current_parent
